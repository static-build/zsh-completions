#!/bin/shell
fpath+="$___X_CMD_ADVISE_MAN_COMPLETIONS_FOLDER/zsh-completions/src"
if [ -f "$___X_CMD_ADVISE_MAN_COMPLETIONS_FOLDER/zsh-completions/zsh-completions_dump.sh" ];then
    . "$___X_CMD_ADVISE_MAN_COMPLETIONS_FOLDER/zsh-completions/zsh-completions_dump.sh"
    return
fi

rm -f "$HOME"/.zcompdump
compinit
[ ! -f "$HOME"/.zcompdump ] || "$___X_CMD_ADVISE_MAN_COMPLETIONS_FOLDER/zsh-completions/zsh-completions_dump.sh" <"$HOME/.zcompdump" 